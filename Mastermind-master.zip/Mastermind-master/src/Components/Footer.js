import React from "react";

function Footer() {
  return (
    <footer>
      Built by Angus
      <br />
      <a href="http://zofiakorcz.pl/mastermind/">
        This game was used as a reference
      </a>
    </footer>
  );
}

export default Footer;
